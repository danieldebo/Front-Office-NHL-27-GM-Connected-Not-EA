# Front Office — Working Efficiently on Replit

**Doc version:** 1.0
**Read this first, every session.**

Replit credits burn per **agent turn**, and the cost of a turn scales with how
much context the agent has to re-read and re-reason. The single biggest waste
isn't building — it's the agent going down a wrong path and needing rework, and
long conversations re-sending their whole history on every message.

This whole package is built to cut that waste: the schema, API, mockups, and
specs are already written, so the agent translates decisions instead of making
them. Here's how to actually spend less.

---

## The five habits that save the most

### 1. One checkpoint per conversation, then start fresh

Agent cost grows with conversation length — every turn re-sends the thread's
history. A 40-message session is paying to re-read 39 messages each turn.

When a checkpoint is approved: **open a new chat.** `replit.md` reloads the rules
for free, so you lose nothing but the expensive backlog. `BUILD_ORDER.md` tells
you what's next.

This one habit saves more than everything else combined.

### 2. Make it plan before it builds — and read the plan

The kickoff prompt already says "tell me your plan before writing code."
**Enforce it.** A 30-second read of the plan where you catch "wait, that's the
wrong table" saves the 5-turn rework loop that actually drains credits.

If the plan is wrong, correct it in one message *before* it writes code. The
course-correction tables in `BUILD_PROMPT.md` exist so you paste a one-liner
instead of letting the agent flail toward the fix.

### 3. Do the free work yourself

Not everything needs an agent. These are things you do directly, at zero credit
cost:

- **Applying a schema file.** Paste `db/schema.sql` (and the deltas) into
  Replit's **database shell / SQL runner** yourself. "Set up the database" is not
  an agent task — it's a `psql` paste. Same for every `schema-*.sql` file.
- **Reading a doc.** You read the spec, then tell the agent the specific thing to
  build. Every turn the agent spends reading a file you could've read is credits
  for nothing.
- **Static content.** The persistent footer (Checkpoint 20) is finished HTML in
  `design/open-leagues-mockup.html` — copy it into the layout yourself. The
  mockups are done; the agent should translate them, never redesign them.
- **Config.** ESP keys, environment variables, connecting the GitHub repo,
  turning on CI — all you, all free.

### 4. Batch your feedback

Let the agent **finish the whole checkpoint**, then give every correction in one
message. Interrupting turn-by-turn means each interruption re-sends context and
restarts its reasoning. One consolidated review beats five live nudges.

### 5. Point precisely; never say "look through everything"

"Build the score-entry endpoint per Checkpoint 4 in BUILD_ORDER.md, matching the
`reportResult` shape in `api/openapi.yaml`" is cheap — it reads two known places.
"Figure out how results should work" is expensive — it reads everything and
guesses. The specificity is the savings.

---

## Per-checkpoint: what to hand the agent vs. do yourself

From `BUILD_ORDER.md`'s "Build vs. buy" column, expanded:

| Checkpoint | You do (free) | Agent does (credits) |
|---|---|---|
| 1 Foundation | — | All of it — this is real scaffolding |
| 2 Leagues/seats/platform | Apply `schema-platform.sql` | League CRUD, platform selector |
| 3 Schedule | — | Circle-method generator (name the algorithm, don't let it invent one) |
| 4 Results | — | The core. Worth the most attention |
| 5 Standings/hub | — | Translate `league-hub-mockup.html` |
| 6 Trust harness | Apply `data-quality-checks.sql` | Tests, property tests, golden fixture |
| 7 Transaction wire | — | Build to `openapi.yaml` shapes |
| 8 Cap ledger | — | Locking is the tricky part |
| 9 Membership | Apply `schema-membership.sql` | Roster, invites, upload |
| 10 Tiers | — | Small — commissioner-scoped field |
| 11 Weekly email | ESP setup, DNS (SPF/DKIM) | Template + outbox send |
| 12 Registry | Apply `schema-keepers.sql` | NHL API sync job |
| 13 Keepers | — | Entry + tenure |
| 14 Stat cards | — | Translate `team-admin-keepers-mockup.html` |
| 15 RLS hardening | — | Non-owner role + policies |
| 16 Marketplace | — | Build to health view |
| 17 Open leagues | Apply `schema-discovery.sql` | Translate `open-leagues-mockup.html` |
| 18 Waitlist | — | Queue mechanics |
| 19 Admin rating | — | The isolation tests matter |
| 20 Footer | **Paste it yourself** | Nothing |
| 21 History | — | Hybrid |
| 22 Charity | Apply `schema-charity.sql` | Build to spec |

You applying the SQL files yourself, across the whole build, is a meaningful
chunk of saved turns on its own — there are eight of them.

---

## The critical-path escape hatch

If credits are tight and you want the thing that matters most working:

**Checkpoints 1 → 2 → 4 → 5.** That's a league with score entry and live
standings — the spreadsheet-killer. Skip 3 (enter a schedule manually at first),
skip 6 (add tests later), defer everything in Phases 2–4. Ship the spine, prove
people use it, then spend credits widening it.

A working spine that 32 people actually use is worth more than a half-built
everything.

---

## Signs you're wasting credits, and the fix

| Sign | Fix |
|---|---|
| The agent is re-reading files it read earlier this session | Start a fresh conversation |
| It's asking what a table is for | Point it at the exact schema file + section |
| It rebuilt something that already worked | You changed scope mid-thread — new chat, clear ask |
| It's "designing" a page | Point it at the mockup; designing is done |
| It's setting up the database | Stop it — paste the SQL yourself |
| Long back-and-forth on one bug | Give the full error + the one file, in one message |
| It added Tailwind / a new lib / an ORM migration | Paste the matching course-correction from `BUILD_PROMPT.md` |

---

## Why the package is shaped this way

Every "already done" artifact in here — the SQL, the OpenAPI contract, the
mockups, the fourteen-plus hard rules in `replit.md`, the course-correction
tables — exists to move decisions *out* of the paid agent loop. The agent's job
is translation and wiring, which is cheap and reliable. Design, architecture, and
correctness rules are settled on paper, which is free. Keep that split and the
credits stretch a long way.
