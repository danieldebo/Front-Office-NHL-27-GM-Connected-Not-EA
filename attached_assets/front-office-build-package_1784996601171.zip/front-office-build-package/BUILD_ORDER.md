# Front Office — Master Build Order

**Doc version:** 1.0
**Purpose:** the single, authoritative list of every checkpoint, in dependency
order, across all phases. When any other doc and this one disagree on numbering,
**this one wins.** Detailed acceptance criteria live in the per-area docs (linked
per checkpoint); this is the map.

Read this before starting any session so you know exactly what you're building
and what it depends on. Building out of order is the most common way to burn a
Replit session — you hit a dependency that doesn't exist yet and the agent
improvises it badly.

---

## The gap this fixes

Earlier numbering skipped the **transaction wire** and **cap ledger** — they were
described in the specs but never got their own checkpoints, even though keepers,
charity, and franchise history all assume they exist. They're now Checkpoints 7
and 8, and everything after shifts accordingly. The list below is complete and
renumbered.

---

## Phase 1 — Replace the spreadsheet (hard September deadline)

Everything here ships before NHL 27 launch. A league that starts on a Google
Sheet won't migrate mid-season.

| # | Checkpoint | Depends on | Spec | Build vs. buy* |
|---|---|---|---|---|
| 1 | Foundation — auth, errors, authz, idempotency, rate limit, pool | — | `PHASE_1_SCOPE.md` | Agent |
| 2 | Leagues, seasons, seats + **platform type** | 1 | `PHASE_1_SCOPE.md`, `db/schema-platform.sql` | Agent |
| 3 | Schedule & availability | 2 | `PHASE_1_SCOPE.md` | Agent (circle-method) |
| 4 | Results & confirmation (version/If-Match) | 2 | `PHASE_1_SCOPE.md` | Agent — the core |
| 5 | Standings & league hub | 4 | `PHASE_1_SCOPE.md`, `design/league-hub-mockup.html` | Hybrid — mockup done |
| 6 | Trust & correctness harness | 4, 5 | `PHASE_1_SCOPE.md`, `db/data-quality-checks.sql` | You apply SQL, agent tests |

**Phase 1 is done when** a commissioner can create a league, fill seats, generate
a schedule, have GMs report and confirm from phones, watch standings update, and
share a public page. If they still need a spreadsheet, it's not done.

---

## Phase 2 — Front office, membership, keepers

Now the record becomes a front office. Move the repo to GitHub before starting
Phase 2 and turn on `ci/github-workflows-ci.yml`.

| # | Checkpoint | Depends on | Spec | Build vs. buy* |
|---|---|---|---|---|
| 7 | **Transaction wire** — trades, signings, approvals, audit trail | 4 | `docs/front-office-v1-spec.md` §3, `api/openapi.yaml` | Agent |
| 8 | **Cap ledger** — cap position, contract tracker, legality, trade locking (H6) | 7 | `docs/front-office-architecture.md` §4 | Agent |
| 9 | Membership provisioning — seat limit, member roster, invites, logo upload | 2 | `docs/membership-addendum.md`, `db/schema-membership.sql` | You apply SQL, agent builds |
| 10 | Relationship tiers (commissioner-private) | 9 | `docs/membership-addendum.md` | Agent — small |
| 11 | Weekly commissioner email — template, outbox send, idempotent | 5, 9 | `docs/membership-addendum.md` | Agent + you (ESP setup) |
| 12 | Player registry — NHL API sync, trigram search, manual entry | 2 | `docs/keeper-addendum.md`, `docs/registry-sync-spec.md`, `db/schema-keepers.sql` | You apply SQL, agent builds job |
| 13 | Keepers — limit, team + commissioner entry, tenure tracking | 9, 12 | `docs/keeper-addendum.md` | Agent |
| 14 | Stat cards — 1/3/5-yr, cached, refresh-on-staleness | 12, 13 | `docs/registry-sync-spec.md` §3, `design/team-admin-keepers-mockup.html` | Hybrid — mockup done |
| 15 | Deferred hardening — Postgres RLS with non-owner role | 1 | `docs/threat-model.md` | Agent — do before Phase 3 exposure |

---

## Phase 3 — Discovery & intake

Making the network discoverable. This is what turns a tool into a network.

| # | Checkpoint | Depends on | Spec | Build vs. buy* |
|---|---|---|---|---|
| 16 | GM marketplace + league health score | 4, 9 | `docs/front-office-v1-spec.md` §3 | Agent |
| 17 | Open leagues & sign-up + ranked division | 2, 16 | `docs/discovery-addendum.md`, `db/schema-discovery.sql` | Hybrid — mockup done |
| 18 | Waitlist — ordered queue, invites, expiry | 17 | `docs/discovery-addendum.md` | Agent |
| 19 | Private admin rating (never subject-visible) | 17 | `docs/discovery-addendum.md` §3 | Agent — test isolation |
| 20 | Persistent footer (DeBo / Venmo) + feature-request modal | 1 | `docs/discovery-addendum.md` §5, `db/schema-feature-request.sql`, `design/open-leagues-mockup.html` | Hybrid — footer static, modal needs endpoint |
| 21 | Franchise history & records pages | 6, 7 | `docs/front-office-data-model.md` | Hybrid |
| 22 | Charity layer — causes, pledges, receipts, champion's choice | 4, 21 | `docs/charity-addendum.md`, `db/schema-charity.sql` | You apply SQL, agent builds |

---

## Phase 4 — Defensibility

| # | Checkpoint | Depends on | Spec | Build vs. buy* |
|---|---|---|---|---|
| 23 | Screenshot ingest (OCR) — needs a labeled eval set first | 4 | `docs/front-office-architecture.md` §10 | Agent + you (eval set) |
| 24 | CSV import for commissioners | 4 | `docs/front-office-data-model.md` §4 | Agent |
| 25 | Export API hardening | — | `api/openapi.yaml` | Agent |

---

\* **Build vs. buy** is the credit-saving column — see `EFFICIENCY.md`:
- **You** — do it yourself, no agent (static content, applying SQL, ESP config).
- **You apply SQL, agent builds** — paste the schema file into the DB shell
  yourself, then hand the agent only the app code.
- **Hybrid** — a mockup or spec is already done; the agent translates, doesn't
  design.
- **Agent** — genuine build work worth an agent session.

---

## One-per-session rule

Each numbered checkpoint is one Replit session. Build it, demo it, approve it,
then **start a fresh conversation** for the next one. `replit.md` reloads the
rules for free every session; a long thread does not. See `EFFICIENCY.md`.

## Critical-path shortcut

If you only had time for the spine: **1 → 2 → 4 → 5**. That's a working league
with score entry and live standings — the thing that replaces the spreadsheet.
Everything else is additive. Don't let a later checkpoint block you from shipping
that spine.
